const cores = ["red", "green", "blue"];
